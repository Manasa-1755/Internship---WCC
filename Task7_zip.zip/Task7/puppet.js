const puppeteer = require('puppeteer-core');

(async () => {
  try {
    const browser = await puppeteer.launch({
      headless: false, // show browser
      executablePath: "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe", 
      userDataDir: "C:\\Users\\Manasa\\AppData\\Local\\Google\\Chrome\\User Data", 
      args: ["--profile-directory=Default"] 
    });

    const page = await browser.newPage();

    // Example: Open Gmail (already logged in with your profile)
    await page.goto("https://mail.google.com");
    console.log("✅ Chrome opened with your real profile");

    // wait 10s so you can see
    await page.waitForTimeout(10000);

    await browser.close();
  } catch (err) {
    console.error("🚨 Puppeteer launch failed:", err);
  }
})();
